function [H,T]=transmatrix(v1,v2,v3)
   l1=v1(1);m1=v1(2);n1=v1(3);
   l2=v2(1);m2=v2(2);n2=v2(3);
   l3=v3(1);m3=v3(2);n3=v3(3);
   T=[l1^2, m1^2, n1^2, l1*m1, m1*n1, n1*l1;
           l2^2, m2^2, n2^2, l2*m2, m2*n2, n2*l2;
           l3^2, m3^2, n3^2, l3*m3, m3*n3, n3*l3;
           2*l1*l2, 2*m1*m2, 2*n1*n2, l1*m2+l2*m1, m1*n2+m2*n1, n1*l2+l1*n2;
           2*l3*l2, 2*m3*m2, 2*n3*n2, l3*m2+l2*m3, m3*n2+m2*n3, n3*l2+l3*n2;
           2*l3*l1, 2*m3*m1, 2*n3*n1, l3*m1+l1*m3, m3*n1+m1*n3, n3*l1+l3*n1
          ];
     H=zeros(6,9);
     for i=1:3
     H(i,4*(i-1)+1)=1;
     end
     for i=4:5
     H(i,4*(i-4)+2)=1;
     H(i,4*(i-3))=1;
     end
     H(6,3)=1;H(6,7)=1;
  
